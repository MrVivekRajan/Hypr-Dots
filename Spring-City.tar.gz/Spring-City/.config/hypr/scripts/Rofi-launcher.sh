## Run
rofi \
    -show drun \
    -theme $HOME/.config/rofi/Rofi.rasi
