#!/bin/bash
pkill eww
eww daemon
eww open bg_widgets
eww open dock